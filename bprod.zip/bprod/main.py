import sys

sys.path.append(
    "/tools/packages/python/3.9.6/platform-linux/arch-x86_64/os-rocky-9.2/python/site-packages/"
)

from PySide2.QtWidgets import QApplication

import qdarktheme

from src import ui_setup

def run_main():
    app = QApplication(sys.argv)
    window = ui_setup.DailiesDashboard()
    app.setStyleSheet(qdarktheme.load_stylesheet())
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    run_main()