import yaml


def create_nuke_stylesheet():
    """
    Create a stylesheet for the Nuke-style interface.

    Returns:
        str: The stylesheet as a string.
    """
    return """
    QWidget {
        background-color: #282828;
        color: #999;
    }
    QPushButton, QLabel, QCheckBox, QRadioButton, QLineEdit, QSlider, QComboBox, QDateEdit, QTextEdit {
        font: bold 10pt 'Helvetica';
        padding: 5px;
        border-radius: 4px;
        border: 1px solid #333;
    }
    QPushButton:hover {
        background-color: #333333;
    }
    QLineEdit, QTextEdit {
        background-color: #333333;
    }
    QSlider::groove:horizontal {
        border: 1px solid #444;
        height: 10px;
        background: #555;
    }
    QSlider::handle:horizontal {
        background: #777;
        border: 1px solid #666;
        width: 18px;
        margin: -2px 0;
        border-radius: 9px;
    }
    QProgressBar {
        border: 2px solid #444;
        border-radius: 5px;
        background-color: #333;
    }
    QProgressBar::chunk {
        background-color: #666;
        width: 20px;
    }
    QComboBox {
        background-color: #333333;
    }
    QComboBox::drop-down {
        subcontrol-origin: padding;
        subcontrol-position: top right;
        width: 15px;
        border-left-width: 1px;
        border-left-color: #444;
        border-left-style: solid;
        border-top-right-radius: 3px;
        border-bottom-right-radius: 3px;
    }
    """

def get_config(filepath = "/home/lokesh.dhundhara/dev/bprod/src/layout_config.yml"):
    config = None

    with open(filepath, "r") as file:
        config = yaml.safe_load(file)

    return config
