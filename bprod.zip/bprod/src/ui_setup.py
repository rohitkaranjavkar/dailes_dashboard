from PySide2.QtWidgets import (
    QMainWindow, QVBoxLayout, QWidget, QLabel, QHBoxLayout,
    QGridLayout, QSpacerItem, QSizePolicy, QSplitter, QFrame,
    QTabWidget, QScrollArea, QListWidgetItem, QListWidget, QLineEdit, QComboBox,
    QDateEdit, QPushButton, QCheckBox
)

from PySide2.QtGui import QPixmap, QIcon, QFont, QStandardItem, QStandardItemModel, QBrush, QColor
from PySide2.QtCore import Qt, QDate, QTime, QModelIndex

from .data_processing import (
    get_thumbnail_data,
    get_stats,
    get_summary,
    get_inital_summary,
    get_show_list,
)

from .utils import (
    create_nuke_stylesheet
)

def clear_layout(layout):
    """
    Clears a given layout by removing all widgets and nested layouts.
    This method will iterate through the layout's items, removing widgets and layouts recursively.
    """
    while layout.count():
        item = layout.takeAt(0)
        if item.widget():
            widget_to_remove = item.widget()
            layout.removeWidget(widget_to_remove)
            widget_to_remove.deleteLater()
        elif item.layout():
            layout_to_remove = item.layout()
            clear_layout(layout_to_remove)
            layout.removeItem(item)


class ShowLayout:
    def __init__(self, show, user_name, initial_data=None):
        self.show = show
        self.right_title_label = None
        self.user_name = user_name
        self.initial_data = initial_data
        self.right_frame = QFrame()
        self.period = "Today"
        self.summary = False
        self.sort_descending = True
        self.right_content_layout = QVBoxLayout()

    def create_show_layout(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        layout.addLayout(self.get_left_layout())

        return layout

    def get_left_layout(self):
        layout = QVBoxLayout()
        splitter = QSplitter(Qt.Horizontal)
        splitter.setHandleWidth(1)

        left_frame = QFrame()
        left_frame.setFrameShape(QFrame.StyledPanel)
        left_frame.setStyleSheet("background-color: #333333;")

        self.frame_layout = QVBoxLayout()
        self.frame_layout.setAlignment(Qt.AlignTop)

        self.grid_layout = QGridLayout()
        
        stats = None

        if self.summary:
            stats = get_summary(self.user_name, self.period, self.initial_data)
        else:
            stats = get_stats(self.user_name, self.period, self.show)

        self.populate_grid_layout(self.grid_layout, stats)
        self.frame_layout.addLayout(self.grid_layout)

        left_frame.setLayout(self.frame_layout)

        splitter.addWidget(left_frame)
        splitter.addWidget(self.create_right_frame())
        splitter.setSizes([350, 650])

        layout.addWidget(splitter)

        left_frame.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        return layout
    
    def load_data(self, from_date, to_date):
        print(f"Loading data from {from_date.toString('yyyy-MM-dd')} to {to_date.toString('yyyy-MM-dd')}")

    def create_right_frame(self):
        self.right_frame.setFrameShape(QFrame.StyledPanel)
        self.right_frame.setStyleSheet("background-color: #333333;")
        self.right_frame.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.right_frame.setMinimumHeight(250)
        self.right_frame.setMinimumWidth(300)

        self.right_title_label = QLabel(f"Select an item from {self.show} on the left")
        self.right_title_label.setStyleSheet("font-size: 16px; font-weight: bold; background-color: #333333;")
        self.right_content_layout.addWidget(self.right_title_label)

        self.right_frame.setLayout(self.right_content_layout)

        return self.right_frame

    def populate_grid_layout(self, layout, stats):
        self.left_widget_rows = []
        self.current_row_widgets = None
        
        row = 0

        layout.setColumnMinimumWidth(0, 50)
        layout.setColumnStretch(0, 0)
        layout.setColumnStretch(1, 1)

        for description, count in stats.items():
            count_label = QLabel(str(count))
            count_label.setMinimumWidth(30)
            count_label.setStyleSheet("")
            count_label.setStyleSheet("color: #0279e8; text-decoration: underline; font-size: 16px;")
            count_label.setTextInteractionFlags(Qt.TextBrowserInteraction)
            count_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            count_label.setFixedHeight(40)

            layout.addWidget(count_label, row, 0)

            description_label = QLabel(description)
            description_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            description_label.setStyleSheet("")
            description_label.setStyleSheet("font-size: 16px;")

            description_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            description_label.setFixedHeight(40)

            layout.addWidget(description_label, row, 1)

            count_label.mousePressEvent = lambda event, desc=description, widgets=(count_label, description_label): self.on_count_clicked(desc, widgets)

            self.left_widget_rows.append((count_label, description_label))
            row += 1
        
        layout.setVerticalSpacing(5)

    def reset_left_row_background(self, widgets):
        if self.current_row_widgets:
            for widget in self.current_row_widgets:
                widget.setStyleSheet(widget.styleSheet().replace("background-color: grey;", ""))

        for widget in widgets:
            widget.setStyleSheet(widget.styleSheet() + "background-color: grey;")

        self.current_row_widgets = widgets
    
    def on_count_clicked(self, description, widgets):
        
        self.reset_left_row_background(widgets)

        show = self.show

        if self.summary:
            show = None

        thumbnail_data = get_thumbnail_data(self.user_name, self.period, description, show)
        self.populate_right_section(thumbnail_data, description)
    
    def populate_right_section(self, thumbnail_data, description):
        clear_layout(self.right_content_layout)

        title_label = QLabel(f"{description} ({len(thumbnail_data)})") 
        title_label.setStyleSheet("font-size: 18px; font-weight: bold; padding: 5px;")
        title_label.setAlignment(Qt.AlignCenter)

        sort_button = QPushButton("Last Update")
        sort_button.setFixedSize(250, 35)
        sort_button.setStyleSheet("""
            QPushButton {
                font-size: 18px;
                padding-right: 60px;
            }
        """)
        sort_button.clicked.connect(lambda: self.sort_and_refresh(thumbnail_data))

        hbox_layout = QHBoxLayout()
        hbox_layout.addWidget(title_label)
        hbox_layout.addWidget(sort_button, alignment=Qt.AlignRight)

        self.right_content_layout.addLayout(hbox_layout)

        self.list_widget = QListWidget()
        self.list_widget.setSpacing(1)
        self.list_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.list_widget.setMinimumSize(300, 200)

        self.populate_list_widget(thumbnail_data)

        self.right_content_layout.addWidget(self.list_widget)
        self.right_content_layout.setContentsMargins(0, 0, 0, 0)
        self.right_content_layout.setSpacing(0)
    
    def populate_list_widget(self, thumbnail_data):
        # Sort the data based on the current sorting order
        sorted_data = dict(sorted(thumbnail_data.items(), reverse=self.sort_descending))

        # Clear the list widget
        self.list_widget.clear()

        for description, item_data in sorted_data.items():
            item_widget = QWidget()
            item_layout = QHBoxLayout(item_widget)

            # Thumbnail label
            thumbnail_label = QLabel()
            if item_data:
                pixmap = QPixmap(item_data)
                if not pixmap.isNull():
                    pixmap = pixmap.scaled(120, 120, Qt.KeepAspectRatio)
                    thumbnail_label.setPixmap(pixmap)
                else:
                    thumbnail_label.setText("(No Image Found)")
            else:
                thumbnail_label.setText("(No Image Available)")

            thumbnail_label.setFixedSize(120, 120)
            thumbnail_label.setStyleSheet("""
                border: 1px solid black;
                QLabel:hover {
                    background-color: #d3d3d3;
                }
            """)

            # Description label
            description_label = QLabel(description)
            description_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            description_label.setStyleSheet("")
            description_label.setStyleSheet("""
                font-size: 16px;
                padding: 5px;
                QLabel:hover {
                    color: #000000;
                }
            """)

            # Time label
            time = "01:30"
            time_text = f"{time.toString('HH:mm')}" if isinstance(time, QTime) else f"{time}"
            time_label = QLabel(time_text)
            time_label.setStyleSheet("")
            time_label.setStyleSheet("""
                font-size: 16px;
                padding-right: 100px;
                QLabel:hover {
                    color: #000000;
                }
            """)
            time_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)

            # Arrange widgets within the item layout
            item_layout.addWidget(thumbnail_label)

            item_layout.addWidget(description_label, alignment=Qt.AlignLeft | Qt.AlignVCenter)
            item_layout.addWidget(time_label, alignment=Qt.AlignRight | Qt.AlignVCenter)

            # Optional: Add spacing around each item
            item_layout.setContentsMargins(5, 5, 5, 5)

            # Add the custom widget to the list widget
            list_item = QListWidgetItem()
            list_item.setSizeHint(item_widget.sizeHint())
            self.list_widget.addItem(list_item)
            self.list_widget.setItemWidget(list_item, item_widget)
        
    def sort_and_refresh(self, thumbnail_data):
        # Toggle sorting order
        self.sort_descending = not self.sort_descending
        
        # Refresh list widget
        self.populate_list_widget(thumbnail_data)

class DailiesDashboard(QMainWindow):
    def __init__(self):
        super(DailiesDashboard, self).__init__()

        self.setStyleSheet(create_nuke_stylesheet())

        self.setWindowTitle("BProd")
        self.setGeometry(100, 100, 1000, 600)

        self.setWindowFlags(Qt.Window | Qt.WindowMinMaxButtonsHint | Qt.WindowCloseButtonHint)
        
        self.right_tab = QTabWidget()
        self.all_tabs = QTabWidget()
        self.dailies_tab = QWidget()

        self.user_name = None
        self.initial_data = None
        self.selected_items = []
        self.current_period = "Today"

        self.init_ui()
        self.tabs_config()

    def init_ui(self):
        # Main widget
        self.init_main_window()
        self.user_name = "rohanarvind"

        self.initial_data = get_inital_summary(self.user_name)
        self.shows = get_show_list(self.initial_data)
        
        # Top Header Section
        self.init_header()

        self.main_layout.addWidget(self.all_tabs)
    
    def init_main_window(self):
        main_widget = QWidget(self)
        self.setCentralWidget(main_widget)
        self.main_layout = QVBoxLayout(main_widget)
    
    def init_header(self):
        header_layout = QHBoxLayout()
        
        header_layout.addLayout(self.filters_layout())
        header_layout.addWidget(self.get_user_info())
        header_layout.setSpacing(10)

        self.main_layout.addLayout(header_layout)
    
    def get_user_info(self):
        user_label = QLabel(self.user_name)
        user_label.setAlignment(Qt.AlignCenter)
        user_label.setStyleSheet("""
            font-size: 24px;
            font-weight: bold;
        """)

        user_label.setFixedHeight(35)
        user_label.setMaximumWidth(250)

        return user_label
    
    def get_header_clear_button(self):
        self.header_clear_button = QPushButton("Clear")
        self.header_clear_button.clicked.connect(self.clear_selections)
        self.header_clear_button.setStyleSheet(
            """
            background-color: #3700B3;
            color: #f0f0f2;
            font-size: 20px;
            font-weight: bold;
            margin-left: 10px;
            height: 35px;
            """
        )
        self.header_clear_button.setFixedWidth(100)

        return self.header_clear_button

    def load_all_tabs(self):
        self.all_tabs.clear()
        first_tab = "Summary"
        
        self.add_tabs(first_tab)

        for item in self.selected_items:
            self.add_tabs(item)

    def add_tabs(self, tab_title):
        current_tab_widget = QWidget()
        self.all_tabs.addTab(current_tab_widget, tab_title)
        
        current_tab_widget.setStyleSheet(
            """
            background-color: #333333;
            """
        )

        self.add_tab_data(current_tab_widget, tab_title)
    
    def add_tab_data(self, tab_widget, tab_title):
        if tab_title == "Summary":
            summary_layout = ShowLayout("Summary", self.user_name, self.initial_data)
            summary_layout.summary = True
            summary_layout.period = self.current_period
            tab_widget.setLayout(summary_layout.create_show_layout())
        
        else:
            show_layout = ShowLayout(tab_title, self.user_name)
            show_layout.period = self.current_period
            tab_widget.setLayout(show_layout.create_show_layout())
        
    
    def filters_layout(self):

        self.load_search_dropdown()

        # Period selection dropdown
        self.period_dropdown = QComboBox()
        self.period_dropdown.addItems(["Today", "This Week", "This Month", "Select Date"])
        self.period_dropdown.setStyleSheet("")
        self.period_dropdown.setStyleSheet(
            """
            QComboBox {
                background-color: #333333;
                font-size: 20px;
                padding: 5px;
                border: 1px solid #666666;
            }
            
            # QComboBox::drop-down {
            #     width: 20px;
            #     background-color: #444444;
            #     border-left: 1px solid #666666;
            # }

            # QComboBox::drop-down::before {
            #     content: '▼';
            #     font-size: 16px;
            #     color: #ffffff;
            #     padding-left: 5px;
            #     padding-right: 5px;
            # }

            # QComboBox::item:selected {
            #     # background-color: #03DAC6;
            #     color: #03DAC6;
            # }
            """
        )
        self.period_dropdown.currentIndexChanged.connect(self.update_period)
        self.period_dropdown.setFixedWidth(150)

        self.enable_date_pickers()

        # Load button
        self.add_load_button()

        # Row layout
        self.filter_row_layout = QHBoxLayout()
        self.filter_row_layout.setSpacing(20)
        self.filter_row_layout.addWidget(self.search_dropdown)
        self.filter_row_layout.addWidget(self.get_header_clear_button())
        self.filter_row_layout.addWidget(self.period_dropdown)
        self.filter_row_layout.addWidget(self.from_date)
        self.filter_row_layout.addWidget(self.to_date)
        # self.filter_row_layout.addWidget(self.date_toggle)
        self.filter_row_layout.addWidget(self.load_button)

        self.filter_row_layout.setAlignment(Qt.AlignLeft)

        # Add row layout to main layout
        return self.filter_row_layout
    
    def load_search_dropdown(self):
        self.search_dropdown = QComboBox()
        self.search_dropdown.setEditable(True)
        self.search_dropdown.setPlaceholderText("Search shows...")
        self.search_dropdown.lineEdit().setPlaceholderText("Search shows...")
        self.search_dropdown.setFixedWidth(self.width() * 0.4)
        self.search_dropdown.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.search_dropdown.setStyleSheet(
            """
            background-color: white;
            font-size: 20px;
            """
        )

        self.search_model = QStandardItemModel(self.search_dropdown)
        self.search_dropdown.setModel(self.search_model)

        self.update_dropdown(self.shows)

        self.search_dropdown.lineEdit().textChanged.connect(self.filter_dropdown)
        
        self.search_model.dataChanged.connect(self.on_item_checked)

    def update_dropdown(self, items):
        """Populates the dropdown with checkable items."""
        self.search_model.clear()
        
        self.search_model.blockSignals(True)
        
        for item_text in items:
            item = QStandardItem(item_text)
            item.setCheckable(True)
            item.setSelectable(False)  # Items are only checkable, not selectable
            self.search_model.appendRow(item)
        
        self.search_model.blockSignals(False)

    def filter_dropdown(self, text):
        """Filters items in the dropdown based on the search text."""
        for row in range(self.search_model.rowCount()):
            item = self.search_model.item(row)
            # Enable or disable the item based on the search match
            if text.lower() in item.text().lower():
                item.setFlags(item.flags() | Qt.ItemIsEnabled)  # Enable matching item
            else:
                item.setFlags(item.flags() & ~Qt.ItemIsEnabled)  # Disable non-matching item
    
    def add_load_button(self):
        self.load_button = QPushButton("Load")
        self.load_button.clicked.connect(self.load_ui)
        self.load_button.setStyleSheet(
            """
            background-color: #3700B3;
            color: #f0f0f2;
            font-size: 20px;
            font-weight: bold;
            min-width: 100px;
            margin-left: 10px;
            height: 35px;
            """
        )
    
    def on_item_checked(self, top_left: QModelIndex, bottom_right: QModelIndex):
        """Called when an item is checked or unchecked (dataChanged signal)."""
        # Check the range of changed data
        for row in range(top_left.row(), bottom_right.row() + 1):
            item = self.search_model.item(row)
            if item.checkState() == Qt.Checked:
                self.selected_items.append(item.text())
                print(f"Item {item.text()} changed state: Checked")

            if item.checkState() == Qt.Unchecked:
                self.selected_items.remove(item.text())
                print(f"Item {item.text()} changed state: Unchecked")
                # item.setForeground(QBrush(QColor("gray")))
        
        self.show_selected_shows()
        return None

    def show_selected_shows(self):
        print(self.selected_items)

    def load_ui(self):
        # Logic to load the rest of the UI
        self.load_all_tabs()
        print("----------load_button is clicked")

    def enable_date_pickers(self):
        # From and To date pickers
        self.from_date = QDateEdit()
        self.to_date = QDateEdit()
        self.from_date.setCalendarPopup(True)
        self.to_date.setCalendarPopup(True)
        self.from_date.setStyleSheet(
            """
            background-color: #333333;
            font-size: 20px;
            width: 100px;
            """
        )
        self.to_date.setStyleSheet(
            """
            background-color: #333333;
            font-size: 20px;
            width: 150px;
            """
        )

        self.from_date.setDisplayFormat("yyyy-MM-dd")
        self.from_date.setDate(QDate.currentDate().addDays(-30))
        # self.from_date.setEnabled(True)
        self.from_date.setFixedWidth(200)

        self.to_date.setDisplayFormat("yyyy-MM-dd")
        self.to_date.setDate(QDate.currentDate())
        # self.to_date.setEnabled(True)
        self.to_date.setFixedWidth(200)
        
        self.from_date.hide()
        self.to_date.hide()

    def update_period(self):
        if self.period_dropdown.currentText() == "Select Date":
            self.current_period = "Today"
            self.from_date.show()
            self.to_date.show()
        else:
            self.current_period = self.period_dropdown.currentText()
            self.from_date.hide()
            self.to_date.hide()

    def clear_selections(self):
        self.search_dropdown.hidePopup()
        """Clears all selections by unchecking all items."""
        self.search_model.blockSignals(True)
        for row in range(self.search_model.rowCount()):
            item = self.search_model.item(row)
            item.setCheckState(Qt.Unchecked)
        self.search_model.blockSignals(False)
        self.selected_items = []
        print("clear selections is clicked")

    def tabs_config(self):
        self.all_tabs.setTabPosition(QTabWidget.North)
        self.all_tabs.setMovable(True)
        self.all_tabs.setTabsClosable(True)

        self.all_tabs.tabBar().setStyleSheet(
            """
            QTabBar {
                background-color: #333333;
            }

            QTabBar::tab {
                background-color: #333333;
                font-size: 20px;
                font-weight: bold;
                min-width: 100px;
                width: auto;
            }
            """
        )


if __name__ == "__main__":
    pass
