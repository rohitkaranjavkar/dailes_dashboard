import sys

sys.path.append("/tools/packages/python/3.9.6/platform-linux/arch-x86_64/os-rocky-9.2/python/site-packages")
sys.path.append("/tools/packages/sgUtils/1.0.2/platform-linux/arch-x86_64/os-rocky-9.2/python")

import random
import create, read
from datetime import date, timedelta, datetime

from .utils import (
    get_config
)

SG = read.SG
SG_DATE_FORMAT = "%Y-%m-%dT%H:%M:%SZ"

def get_thumbnail_data_old(show, thumbnail_type, period):
    final_data = {
        "erypevi": "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-52-23.jpeg",
        "nrekedc": "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-53-29.jpeg",
        "qdr": "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-53-59.jpeg",
        "viuvmfio": "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-54-34.jpeg",
        "pdyn": "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-52-23.jpeg",
        "xgy": "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-53-29.jpeg",
        "jedjeqli": "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-53-59.jpeg",
        "jkvjsdro": "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-54-34.jpeg",
        "yutylb": "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-52-23.jpeg",
        "btdyezg": "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-53-29.jpeg",
    }

    return final_data

def refactor_user_name(user_name):
    if "." in user_name:
        user_name = user_name.replace(".", "-")
    
    return user_name

def get_user_id_from_user_name(user_name):
    user_name = refactor_user_name(user_name)
    user = SG.find_one("HumanUser", [["sg_username", "is", user_name]], ["id"])

    if user:
        return user["id"]
    
    return None

def get_shows_for_user(user_name):
    user_name = refactor_user_name(user_name)
    
    user = SG.find_one("HumanUser", [["sg_username", "is", user_name]], ["id", "name", "projects", "department", "groups"])

    if not user:
        print(f"No data found for {user_name}")
        return None
    
    project_name = [project["name"] for project in user["projects"]]

    active_complete_projects = SG.find(
        "Project",
        [["name", "in", project_name], ["sg_status", "in", ["Active", "Complete"]]],
        fields=["id", "name"]
    )

    return [project["name"] for project in active_complete_projects]

def get_shot_info(user_id, start_date, end_date, keys, project_name=None):
    status_operator = "in" if isinstance(keys, list) else "is"

    filters = [
        ["sg_status_list", status_operator, keys],
        ["sg_task.Task.task_reviewers", "is", {"type": "HumanUser", "id": user_id}],
        ["updated_at", "between", [start_date, end_date]]
    ]

    if project_name:
        project = SG.find_one("Project", [["name", "is", project_name]])
        filters.append(["project", "is", project])

    required_version = SG.find(
        "Version",
        filters,
        ["code", "sg_path_to_frames", "project", "sg_package"]
    )

    return required_version

def get_project_stats(all_data):
    output = {}

    # Loop through each item in the list
    for data in all_data:
        project_name = data['project']['name']
        version_info = {
            "code": data["code"],
            "sg_path_to_frames": data["sg_path_to_frames"]
        }

        # Add version info under the correct project name
        if project_name not in output:
            output[project_name] = [version_info]  # Create a new list if project not in output
        else:
            output[project_name].append(version_info)  # Append to existing list if project exists
    
    return output

def coustom_print(current_data):
    for item in current_data:
        print(f"path to frame: {item['sg_path_to_frames']} , sg_package: {item['sg_package']}")

def get_inital_summary(user_name):
    current_config = get_config()["Supervisor"]
    user_id = get_user_id_from_user_name(user_name)

    end_date = date.today()
    start_date = end_date - timedelta(days=30)

    start_date_str = datetime.combine(start_date, datetime.min.time()).strftime(SG_DATE_FORMAT)
    end_date_str = datetime.combine(end_date, datetime.max.time()).strftime(SG_DATE_FORMAT)

    current_stats = {}

    for item in current_config:
        current_data = get_shot_info(user_id, start_date_str, end_date_str, current_config[item])

        current_stats[item] = get_project_stats(current_data)
    
    return current_stats


def get_stats(user_name, period, project_name=None):
    # TODO: OPtimise this to load the config only once
    current_config = get_config()["Supervisor"]
    user_id = get_user_id_from_user_name(user_name)

    if not user_id:
        return {}

    current_stats = {}

    for item in current_config:
        current_stats[item] = 0

    end_date = date.today()
    
    if period == "Today":
        start_date = end_date
    elif period == "This Week":
        start_date = end_date - timedelta(days=end_date.weekday())
    elif period == "This Month":
        start_date = end_date - timedelta(days=30)
    
    start_date_str = datetime.combine(start_date, datetime.min.time()).strftime(SG_DATE_FORMAT)
    end_date_str = datetime.combine(end_date, datetime.max.time()).strftime(SG_DATE_FORMAT)

    for item in current_stats:
        shot_info = get_shot_info(user_id, start_date_str, end_date_str, current_config[item], project_name)
        current_stats[item] += len(shot_info)

    return current_stats

def get_show_list(summary_data):
    show_list = []

    for item in summary_data:
        show_list.extend(summary_data[item].keys())
    
    return show_list

def get_summary(user_name, period, show_data):
    all_shows = get_show_list(show_data)
    
    if not all_shows:
        return None

    summary = {}
    current_config = get_config()["Supervisor"]

    for item in current_config:
        summary[item] = 0

    for show in all_shows:
        stats = get_stats(user_name, period, show)
        
        if not stats:
            continue
        
        for item in current_config:
            summary[item] += stats[item]
        
    return summary

def get_thumbnail_path():
    final_data = [
        "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-52-23.jpeg",
        "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-53-29.jpeg",
        "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-53-59.jpeg",
        "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-54-34.jpeg",
        "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-52-23.jpeg",
        "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-53-29.jpeg",
        "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-53-59.jpeg",
        "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-54-34.jpeg",
        "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-52-23.jpeg",
        "/home/lokesh.dhundhara/dev/bprod/tests/data/Screenshot_from_2024-10-10 12-53-29.jpeg"
    ]

    random_number = random.randint(0, 9)

    return final_data[random_number]

def get_detail(user_name, period, filter, project_name=None):
    # TODO: OPtimise this to load the config only once
    current_config = get_config()["Supervisor"]
    user_id = get_user_id_from_user_name(user_name)

    if not user_id:
        return None

    end_date = date.today()
    
    if period == "Today":
        start_date = end_date
    elif period == "This Week":
        start_date = end_date - timedelta(days=end_date.weekday())
    elif period == "This Month":
        start_date = end_date - timedelta(days=30)
    
    start_date_str = datetime.combine(start_date, datetime.min.time()).strftime(SG_DATE_FORMAT)
    end_date_str = datetime.combine(end_date, datetime.max.time()).strftime(SG_DATE_FORMAT)


    shot_info = get_shot_info(user_id, start_date_str, end_date_str, current_config[filter], project_name)

    codes = [version["code"] for version in shot_info]

    return codes

def get_thumbnail_data(user_name, period, thumbnail_type, show=None):
    details = get_detail(user_name, period, thumbnail_type, show)

    final_data = {}

    for item in details:
        final_data[item] = get_thumbnail_path()

    return final_data

if __name__ == "__main__":
    # user_name = "rohitk"
    # user_name = "tejas.nikam"
    	
    user_name = "rohanarvind"

    # shows = get_shows_for_user(user_name)
    # ["CN_TWIN", "FT_N1899", "OOU_STREETDOGS", "CGEV_ND1", "CGEV_COMBATTANTES", "CGEV_NOUVEAUJOUET", "UTD_NATWEST", "FT_HCM"]
    # print(shows)



    # show_name = shows[0]
    # for show in shows:
    # stats = get_stats(show_name, user_name, "This Month")
    # print(stats)

    # show_name = "oou_tb"

    final_data = get_inital_summary(user_name)
    shows = get_show_list(final_data)

    print(shows)


    # get_summary

    # project_names = []

    # for show in shows:
    #     project = SG.find_one("Project", [["name", "is", show]], fields=["sg_status", "name"])
        
    #     if project["sg_status"] in ["Complete, Active"]:
    #         project_names.append(project["name"])

    #     print(project)


    print("------------------ Done testing")

    # {
    #     data["project"]["name"] : [
    #         {
    #             "code": data["code"],
    #             "sg_path_to_frames": data["sg_path_to_frames"]
    #         },
    #         {
    #             "code": data["code"],
    #             "sg_path_to_frames": data["sg_path_to_frames"]
    #         }
    #         .
    #         .
    #         .
    #         .
    #         .
    #         and so on
    #     ]
    # }
    # ['BOULT_CORAL3', 'oou_tb', 'ft_velvet_sg', 'ft_peru', 'cmt_abb', 'bfu_mro', 'oou_dep', 'tay_cho', 'oou_hg', 'oou_tb']
